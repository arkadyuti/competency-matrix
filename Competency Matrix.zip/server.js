var express = require('express');
var bodyParser = require("body-parser");
var expressSession = require('express-session');
var app = express();

app.use("/dist" , express.static(__dirname + '/dist'));
app.use(bodyParser.json());
app.use(bodyParser.text());
app.use(expressSession({secret:'max',saveUninitialized:false,resave:false}));
var routes = require("./routes.js")(app);

var server = app.listen(3001, function () {
    console.log("Listening on port %s...", server.address().port);
});