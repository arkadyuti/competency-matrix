var path = require("path");
var fs = require('fs');
var bodyParser = require('body-parser');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var nodemailer = require('nodemailer');

var jsonFile = './dist/json/supervisor.json';
var contents = fs.readFileSync(jsonFile).toString();
var jsonData = JSON.parse(contents);

var jsonSkill = './dist/json/skills.json';
var jsonDataContents = fs.readFileSync(jsonSkill).toString();
var jsonSkillData = JSON.parse(jsonDataContents);

var credentails = {
    user: "dalalayan1@gmail.com",
    pass: "52051600"
};

var appRouter = function (app) {
    app.use(cookieParser());
     app.use( bodyParser.json() );       // to support JSON-encoded bodies
     app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
       extended: true
     }));
 
    app.get("/", function (req, res) {
        res.sendFile(path.join(__dirname + '/dist/html/login-page.html'));
    });

    app.post("/login", function (req, res) {
      console.log("############");
      if( req.session.user ){
          console.log('already signed in');
          res.cookie('oracle_id', jsonData.logincredentials[userCredentials.name].oracle_id);
          res.redirect('/LandingPage_Supervisee');
      } else{
        console.log('signing in..');
        var userCredentials =req.body;

        var user = userCredentials.name;
        
        var unhashedPassword = (new Buffer(userCredentials.password, 'base64')).toString();
        if((jsonData.logincredentials[userCredentials.name]) && (jsonData.logincredentials[userCredentials.name].password ===unhashedPassword)){
              res.cookie('oracle_id', jsonData.logincredentials[userCredentials.name].oracle_id);
                res.send('success');
                req.session.user = user;
                console.log(req.session.user);
        }
        else{
        res.send('invalid');
        }  
      }
           
    });

   /* app.post("/LandingPage", function (req, res) {
           var logedinUser = req.body.logedinUser;
           var data = jsonData[logedinUser]
           res.send(data);  
              
       });*/

     app.get("/LandingPage_Supervisee", function (req, res) {
           
           var data = jsonData;
           res.send(data);     
  });


    app.post("/DeleteSupervisee", function (req, res) {
           var data = req.body
           
           var superviseeList = data.superviseeList;
           var supervisor = data.supervisor;
           jsonData[supervisor].supervisee_list = superviseeList;
           console.log(jsonData[supervisor].supervisee_list);
           
           /*res.send(data);*/     
  });




  app.post("/updateDataFetch", function (req, res) {
       var loginUserId = req.body.loggedinUserId;
       console.log(loginUserId);
      res.send(jsonData[loginUserId]);
  }); 
app.post("/updatePic", function (req, res) { 
 var image=req.body;
       console.log(req.body);
       console.log(image);
       var loggedinUserId=image.loggedinUserId;
       var src=image.imgsrc;
       jsonData[loggedinUserId].profile_photo = src;
       fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
       res.send(image);
  }); 
app.post("/update", function (req, res) { 
        var data = req.body;

         console.log(data);
         var name=data.name;
         console.log(name);
         var designation=data.designation;
         var address=data.address;
         var datasrc = data.src;
         var loggedinUserId=data.loggedinUserId;
         jsonData[loggedinUserId].username = name;
         jsonData[loggedinUserId].designation = designation;
         jsonData[loggedinUserId].address = address;
        
        fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
        res.redirect("/");
        res.send(data);
               


  }); 
app.post("/star-data", function (req,res) {
    superviseeID = req.cookies["superviseeID"];
    var starObject = req.body;
    if(starObject.skillType === "primarySkills"){
        console.log("S");
        for (var i = 0; i < jsonData[superviseeID].primaryskills.length; i++) {
            if((jsonData[superviseeID].primaryskills[i].skillName) === starObject.mainSkill){
                for(var j = 0; j<jsonData[superviseeID].primaryskills[i].subSkill.length; j++){
                    if((jsonData[superviseeID].primaryskills[i].subSkill[j].subSkillName) === starObject.subSkillValue){
                        jsonData[superviseeID].primaryskills[i].subSkill[j].rating = starObject.starValue;
                        var jsonFile = './dist/json/supervisor.json';
                        fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
                        res.send(jsonData);
                        break;
                    }
                }
                break;
            }
        }
    }else {
        console.log("SS");
        for (var i = 0; i < jsonData[superviseeID].secondaryskills.length; i++) {
            if((jsonData[superviseeID].secondaryskills[i].skillName) === starObject.mainSkill){
                for(var j = 0; j<jsonData[superviseeID].secondaryskills[i].subSkill.length; j++){
                    if((jsonData[superviseeID].secondaryskills[i].subSkill[j].subSkillName) === starObject.subSkillValue){
                        jsonData[superviseeID].secondaryskills[i].subSkill[j].rating = starObject.starValue;
                        var jsonFile = './dist/json/supervisor.json';
                        fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
                        res.send(jsonData);
                        break;
                    }
                }
                break;
            }
        }
    }
    // receivedData = req.body;
    // jsonData[superviseeID].primaryskills.push(receivedData.primaryskills[0]);
    // var jsonFile = './dist/json/supervisor.json';
    // fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
    // res.send(jsonData);
  });
app.get("/dashboard", function (req, res) {
      res.sendFile(path.join(__dirname + '/dist/html/dashboard.html'));
  });
  app.get("/skill-data", function (req, res) {
    superviseeID = req.cookies["superviseeID"];
    var parsedData = jsonData[superviseeID];
    parsedData.dictonary = jsonSkillData;
    res.send(parsedData);
  });
  app.post("/skill-data-post", function (req,res) {
    superviseeID = req.cookies["superviseeID"];
    console.log(req.body);
    receivedData = req.body;
    jsonData[superviseeID].primaryskills.push(receivedData.primaryskills[0]);
    var jsonFile = './dist/json/supervisor.json';
    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
    res.send(jsonData);
  });
  app.post("/skill-data-post-secondary", function (req,res) {
    superviseeID = req.cookies["superviseeID"];
    receivedData = req.body;
    jsonData[superviseeID].secondaryskills.push(receivedData.secondaryskills[0]);
    var jsonFile = './dist/json/supervisor.json';
    fs.writeFileSync(jsonFile, JSON.stringify(jsonData));
    res.send(jsonData);
  });
  app.get("/skill-dictionary", function (req, res) {
    //var parsedJson = JSON.parse(jsonSkill);
    res.send(jsonSkillData);
  });

app.post("/sendPassword",function(req,res){
  console.log("############@@@");
  console.log(req.body.password);
  var pass = req.body.password;
  var username= req.body.username;
  jsonData.logincredentials[username].password=pass;
     res.send("success");
});

app.post("/sendEmail",function(req,res){
  console.log("############");
     var username = req.body.username;
     var userId = jsonData.logincredentials[username].oracle_id;
     var email = jsonData[userId].email_id;
     var mailOptions = {
        from: '"Sapient Support" <'+ credentails.user +'>', // sender address
        to: email, // list of receivers
        subject: "Hello", // Subject line
        html: "<a href='http://localhost:3001/dist/html/changePassword.html?username="+username+"'>Click here</a>" // plaintext body
        };

        var smtpTransport = nodemailer.createTransport("SMTP", {
            service: "Gmail",
            auth: credentails
        });

      // send mail with defined transport object
      smtpTransport.sendMail(mailOptions, function(error, info){
        if(error){
            return console.log(error);
        }
        console.log('Message sent: ' + JSON.stringify(info));
        res.send("success");
        smtpTransport.close();
    });

});   

}

module.exports = appRouter;
