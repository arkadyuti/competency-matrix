"use strict";
var competencyMatrix=competencyMatrix||{};
$(document).ready(function(){
  var imgsrc;
  var loggedinUserId=globalFunction.getCookie ("oracle_id");
  $.ajax({
    url: "/updateDataFetch",
    type:"POST", 
    data:{"loggedinUserId":loggedinUserId},
    success: updateCallBackDisplay,
    error:function(argument){
         console.log(argument);
     }
    });
  function updateCallBackDisplay(result){
          var source = $("#user-detail-template").html(); // grab the template
          var template = Handlebars.compile(source);    //compile template
          var context=result;
          var leftPanelTemplate = template(context);
          $('.left-user-panel').html(leftPanelTemplate);
 
          var update = $("#user-update-template").html(); // grab the template
          var template = Handlebars.compile(update);
          var updateProfileTemplate=template(context);
          $(".detail-supervisors").html(updateProfileTemplate);
          $("#update-employeeId-field").attr('disabled', 'true');
          
       
       var readURL = function(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
           reader.onload = function (evnt) {
                $('#user-pic').attr('src', evnt.target.result);
                imgsrc= evnt.target.result;  
            /*     $.ajax({
                  url: '/updatePic',
                  type: 'POST',
                  dataType: 'application/json', 
                  data:{"loggedinUserId":loggedinUserId,
                    "imgsrc":imgsrc},      
          success:function(argument){
            console.log(argument);
          },
          error:function (argument) {
             console.log(argument);
          }
                  
         }); */
      } 
          
          reader.readAsDataURL(input.files[0]);  
        }
      }
        
    
 
      $(".file-upload").on('change', function(){
        readURL(this);
      });
    
      $(document).on("click",".user-picture",function(evnt) {
       
        $(".file-upload").click();
         evnt.preventDefault();
        
      });
      $(".update-profile-cancel").click(function(evnt){
       window.location.href="/dist/html/landing-page.html";
         evnt.preventDefault();
      });
      $(".update-profile-update").click(function(evnt){
        
         var name=$("#update-name-field").val();
         var designation=$("#update-designation-field").val();
         var address=$("#update-address-field").val();
         /*var nameRegex=new RegExp("^[A-Za-z0-9_-\s]{6,10}$");
         var designationRegex=new RegExp("^[a-zA-Z.\s]$");
         var addressRegex=new RegExp("^[#\d\sA-z]{1,20}$");
         if(nameRegex.test(name)&&designationRegex.test(designation)){
            if(addressRegex.test(address)){
          name=name;
          designation=designation;
           address=address;
         }
     }*/
         /*else{
          throw new Error("error"); 
         }*/
         
         var params={
            "loggedinUserId":loggedinUserId,
            "name":name,
             "imgsrc":imgsrc,
            "designation":designation,
            "address":address
           
          };
         
         $.ajax({
                  url: '/update',
                  type: 'POST',
                  dataType: 'application/json',
                  data:params,
          success:function(argument){
           console.log(argument);
          },
          error:function (argument) {
            throw new Error("Unable to post the data");
          }
                  
         }); 
    
     window.location.href="/dist/html/landing-page.html";
            evnt.preventDefault();
    });
    }
     });
    


